package pageObject;


import cucumber.api.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import static java.lang.Thread.sleep;

public class PageFunction {

    public static void clickLearnMoreButton(WebDriver driver) throws InterruptedException {
        String xpath="//p[@class='dbs-group']//button[text()='Learn More']";
        WebElement element=driver.findElement(By.xpath(xpath));
        sleep(7000);
        element.click();
    }

    public static void clickSustainabilityLink(WebDriver driver) throws InterruptedException {
        String xpath="//div[@class='navbar-links-left']/ul/li/a[text()='Sustainability']";
        WebElement element=driver.findElement(By.xpath(xpath));
        sleep(7000);
        element.click();
    }

    public static void clickCreatingSocialImpactLink(WebDriver driver) throws InterruptedException {

        String xpath="//div/ul/li/a[text()='Creating Social Impact']";
        WebElement element=driver.findElement(By.xpath(xpath));
        sleep(5000);
        element.click();
    }

    public static void clickDBSStrongerTogetherFundLink(WebDriver driver) throws InterruptedException {

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(5000);
        String xpath="//a[text()='DBS Stronger Together Fund']";
        WebElement element=driver.findElement(By.xpath(xpath));
        Thread.sleep(5000);
        element.click();
    }

    public static void scrollDownAndNavigateToSingaporeOnTheLeftPanel(WebDriver driver) throws InterruptedException {

        String xpath="//section/div[1]/div[1]/div/div[2]/ul/li[3]/a";
        WebElement element = driver.findElement(By.xpath(xpath));
        Thread.sleep(5000);
        element.click();
    }

    public static void clickAboutHeaderTab(WebDriver driver) throws InterruptedException {

        String xpath="//div[@class='navbar-links-left']/ul/li/a[text()='About']";
        WebElement element = driver.findElement(By.xpath(xpath));
        Thread.sleep(5000);
        element.click();
    }

    public static void clickWhoWeAreLink(WebDriver driver) throws InterruptedException {

        String xpath="//div[@class='navbar-overflow-content']//ul/li/a[text()='Who We Are']";
        WebElement element = driver.findElement(By.xpath(xpath));
        Thread.sleep(5000);
        element.click();
    }

    public static void clickOurAwardsAndAccoladesLink(WebDriver driver) throws InterruptedException {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(2000);
        String xpath="//div//a[text()='Our Awards & Accolades']";
        WebElement element = driver.findElement(By.xpath(xpath));
        Thread.sleep(5000);
        element.click();
    }

    public static void verifyTheTotalNumberOfAwards(WebDriver driver) {

        String xpath = "//div[@class='row mBot-20']";
        try {
            Thread.sleep(6000);
            List<WebElement> elementList = driver.findElements(By.xpath(xpath));
            int count = elementList.size();
            if(count==22)
            {
                Assert.assertTrue(true);
            }
            else {
                Assert.assertFalse(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void verifyAllTheAwardNameAndCaptionOfTheAwards(WebDriver driver) {


            String xpath="//div[@class='rich-text-box']//div[@class='row mBot-20']/..//h3/strong";
            String xpath1;
            ArrayList<String> arrayList=new ArrayList<>();
            List<WebElement> elementList1;
            String elements;
            String elements1;


               try{
                sleep(6000);
                List<WebElement> elementList = driver.findElements(By.xpath(xpath));
                //List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
                int count = elementList.size();
                int count1;
                for(int i=0;i<count;i++)
                {
                    elements=elementList.get(i).getText();
                    System.out.println(elements);
                    xpath1="//div[@class='rich-text-box']//div[@class='row mBot-20']/..//h3/strong[text()='"+elements+"']/../following-sibling::p";
                    elementList1 = driver.findElements(By.xpath(xpath1));
                    count1 = elementList1.size();
                    for(int j=i;j<count1;j++)
                    {
                        elements1=elementList1.get(j).getText();
                        System.out.println(arrayList.add(elements1));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();

            }
    }

}
