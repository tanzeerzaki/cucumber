package stepDefinition;


import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import pageObject.Common;
import pageObject.PageFunction;


import static java.lang.Thread.sleep;

public class StepDefinitions {

    public static WebDriver driver;
    PageFunction pageFunction=null;
    Common common=null;

    Scenario sce;
    @Before
    public void setup(Scenario s)
    {
        this.sce = s;
    }

    @After
    public void tearDown(){
        driver.close();
        driver.quit();
        sce.write("Browser is closed");
    }

    @Given("^Launch the URL$")
    public void launch_the_url() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","src//main//resources//chromedriver.exe");
        ChromeOptions cap = new ChromeOptions();
        cap.setCapability("applicationCacheEnabled", false);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        Thread.sleep(4000);
        sce.write("Chrome Driver invoked");
        String url="https://www.dbs.com.sg/index/default.page";
        driver.get(url);
        sleep(3000);
        sce.write("URL navigate as : "+url);
        common.takeScreenshot(driver,sce);
    }

    @When("^Click on Learn More button$")
    public void Click_on_Learn_More_button() throws InterruptedException {

       PageFunction.clickLearnMoreButton(driver);
       sce.write("Learn More button clicked");
       common.takeScreenshot(driver,sce);

    }

    @Then("^Click on Sustainability link$")
        public void Click_On_Sustainability_link() throws InterruptedException {

        pageFunction.clickSustainabilityLink(driver);
        sce.write("Sustainability link clicked");
        common.takeScreenshot(driver,sce);
        }

    @Then("^Click on Creating Social Impact link$")
    public void Click_on_Creating_Social_Impact_link() throws InterruptedException {
        pageFunction.clickCreatingSocialImpactLink(driver);
        sce.write("Creating Social Impact link clicked");
        common.takeScreenshot(driver,sce);
    }

    @Then("^Click on DBS Stronger Together Fund link$")
    public void Click_on_DBS_Stronger_Together_Fund_link() throws InterruptedException {
        pageFunction.clickDBSStrongerTogetherFundLink(driver);
        sce.write("DBS Stronger Together Fund link clicked");
        common.takeScreenshot(driver,sce);
    }

    @Then("^Scroll down and navigate to Singapore on the left panel$")
    public void Scroll_down_and_navigate_to_Singapore_on_the_left_panel() throws InterruptedException {
        pageFunction.scrollDownAndNavigateToSingaporeOnTheLeftPanel(driver);
        sce.write("Scroll down and navigate to Singapore on the left panel");
        common.takeScreenshot(driver,sce);
    }

    @Then("^Navigate to About in the header tab$")
    public void Navigate_to_About_in_the_header_tab() throws InterruptedException {
        pageFunction.clickAboutHeaderTab(driver);
        sce.write("About Header Tab clicked");
        common.takeScreenshot(driver,sce);
    }

    @Then("^Navigate to Who we are tab$")
    public void Navigate_to_Who_we_are_tab() throws InterruptedException {
        pageFunction.clickWhoWeAreLink(driver);
        sce.write("Who we are link clicked");
        common.takeScreenshot(driver,sce);
    }

    @Then("^Navigate to Our Awards & Accolades$")
    public void NavigateToOurAwardsAndAccolades() throws InterruptedException {
        pageFunction.clickOurAwardsAndAccoladesLink(driver);
        sce.write("Our Awards & Accolades link clicked");
        common.takeScreenshot(driver,sce);
    }

    @And("^Validate the total number of awards displayed on the page is 22$")
    public void verifyTotalNumberOfAwards() {
        pageFunction.verifyTheTotalNumberOfAwards(driver);
        sce.write("Verified The Total number of awards awards displayed on the page is 22");
        common.takeScreenshot(driver,sce);
    }
    @Then("^Validate all the award name and caption of the awards$")
    public void verifyAllTheAwardNameAndCaption() {
        pageFunction.verifyAllTheAwardNameAndCaptionOfTheAwards(driver);
        sce.write("Verified all the award name and caption of the awards");

    }

}
